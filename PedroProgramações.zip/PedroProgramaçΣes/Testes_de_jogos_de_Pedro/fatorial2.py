import time
import math

# Define o labirinto como uma lista de strings
labirinto = [
    "##########",
    "#S#   #  #",
    "# # # # ##",
    "# #   #  #",
    "#   # ###",
    "##### ## #",
    "#   #    #",
    "## # ### ##",
    "#  # #    #",
    "# #### ###",
    "# ####   #",
    "#  #  ## #",
    "######## #",
    "##        #",
    "## #######",
    "##        #",
    "#########E#",
]

# Função para imprimir o labirinto
def imprimir_labirinto(lab):
    for linha in lab:
        print(linha)

# Função para encontrar a posição do jogador
def encontrar_posicao(lab, caracter):
    for i, linha in enumerate(lab):
        for j, coluna in enumerate(linha):
            if coluna == caracter:
                return i, j
    return None

# Função principal do jogo
def jogo_de_labirinto():
    jogador = 'S'
    objetivo = 'E'
    posicao_jogador = encontrar_posicao(labirinto, jogador)
    
    while True:
        imprimir_labirinto(labirinto)
        movimento = input("Para onde deseja ir? (W/A/S/D): ").upper()
        
        if movimento == 'W':
            nova_posicao = (posicao_jogador[0] - 1, posicao_jogador[1])
        elif movimento == 'S':
            nova_posicao = (posicao_jogador[0] + 1, posicao_jogador[1])
        elif movimento == 'A':
            nova_posicao = (posicao_jogador[0], posicao_jogador[1] - 1)
        elif movimento == 'D':
            nova_posicao = (posicao_jogador[0], posicao_jogador[1] + 1)
        else:
            print("Movimento inválido. Use W/A/S/D para se mover.")
            continue
        
        if labirinto[nova_posicao[0]][nova_posicao[1]] == '#':
            print("Você não pode atravessar paredes.")
        elif labirinto[nova_posicao[0]][nova_posicao[1]] == objetivo:
            print("Parabéns, você chegou ao objetivo!")
            break
        else:
            labirinto[posicao_jogador[0]] = labirinto[posicao_jogador[0]][:posicao_jogador[1]] + ' ' + labirinto[posicao_jogador[0]][posicao_jogador[1] + 1:]
            labirinto[nova_posicao[0]] = labirinto[nova_posicao[0]][:nova_posicao[1]] + jogador + labirinto[nova_posicao[0]][nova_posicao[1] + 1:]
            posicao_jogador = nova_posicao

# Iniciar o jogo de labirinto
jogo_de_labirinto()
