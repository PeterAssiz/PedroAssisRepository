import pygame
import random
import sys

# Inicialização do Pygame
pygame.init()

# Configurações da tela
largura = 540
altura = 600
tamanho_celula = largura // 9
cor_fundo = (255, 255, 255)
cor_linhas = (0, 0, 0)
cor_numero = (0, 0, 0)

# Configurações da fonte
pygame.font.init()
fonte = pygame.font.Font(None, 36)

# Criação da janela do Pygame
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Sudoku")

def criar_tabuleiro_vazio():
    return [[0 for _ in range(9)] for _ in range(9)]

def imprimir_tabuleiro(tabuleiro):
    for linha in range(9):
        for coluna in range(9):
            numero = tabuleiro[linha][coluna]
            if numero != 0:
                texto = fonte.render(str(numero), True, cor_numero)
                x = coluna * tamanho_celula + tamanho_celula // 2 - 10
                y = linha * tamanho_celula + tamanho_celula // 2 - 10
                tela.blit(texto, (x, y))

def validar_numero(tabuleiro, linha, coluna, numero):
    # Verifica a linha
    if numero in tabuleiro[linha]:
        return False

    # Verifica a coluna
    if numero in [tabuleiro[i][coluna] for i in range(9)]:
        return False

    # Verifica o quadrante 3x3
    quadrante_linha = linha // 3
    quadrante_coluna = coluna // 3
    for i in range(quadrante_linha * 3, (quadrante_linha + 1) * 3):
        for j in range(quadrante_coluna * 3, (quadrante_coluna + 1) * 3):
            if tabuleiro[i][j] == numero:
                return False

    return True

def resolver_sudoku(tabuleiro):
    vazio = encontrar_vazio(tabuleiro)
    if not vazio:
        return True
    linha, coluna = vazio

    for numero in range(1, 10):
        if validar_numero(tabuleiro, linha, coluna, numero):
            tabuleiro[linha][coluna] = numero
            if resolver_sudoku(tabuleiro):
                return True
            tabuleiro[linha][coluna] = 0

    return False

def encontrar_vazio(tabuleiro):
    for i in range(9):
        for j in range(9):
            if tabuleiro[i][j] == 0:
                return (i, j)
    return None

def gerar_jogo_sudoku():
    tabuleiro = criar_tabuleiro_vazio()
    resolver_sudoku(tabuleiro)
    
    # Remove alguns números aleatoriamente para criar o jogo
    for _ in range(40):
        linha = random.randint(0, 8)
        coluna = random.randint(0, 8)
        while tabuleiro[linha][coluna] == 0:
            linha = random.randint(0, 8)
            coluna = random.randint(0, 8)
        tabuleiro[linha][coluna] = 0

    return tabuleiro

jogo_sudoku = gerar_jogo_sudoku()

def detectar_clique(tabuleiro):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.unicode.isdigit() and 1 <= int(event.unicode) <= 9:
                linha, coluna = pygame.mouse.get_pos()
                linha //= tamanho_celula
                coluna //= tamanho_celula
                if tabuleiro[linha][coluna] == 0:
                    tabuleiro[linha][coluna] = int(event.unicode)
    
    # Detectar clique do mouse
    if pygame.mouse.get_pressed()[0]:  # Botão esquerdo do mouse
        pos_mouse = pygame.mouse.get_pos()
        coluna_clicada = pos_mouse[0] // tamanho_celula
        linha_clicada = pos_mouse[1] // tamanho_celula

        # Verificar se a célula clicada está vazia
        if tabuleiro[linha_clicada][coluna_clicada] == 0:
            # Aqui você pode implementar a lógica para permitir ao jogador inserir um número clicando
            # Você pode usar um evento de teclado simulado para isso, semelhante ao código acima
            pass

# Loop do jogo
while True:
    detectar_clique(jogo_sudoku)
    tela.fill(cor_fundo)

    # Desenha linhas do tabuleiro
    for i in range(1, 9):
        if i % 3 == 0:
            espessura = 2
        else:
            espessura = 1
        pygame.draw.line(tela, cor_linhas, (0, i * tamanho_celula), (largura, i * tamanho_celula), espessura)
        pygame.draw.line(tela, cor_linhas, (i * tamanho_celula, 0), (i * tamanho_celula, altura - tamanho_celula), espessura)

    imprimir_tabuleiro(jogo_sudoku)

    pygame.display.update()
