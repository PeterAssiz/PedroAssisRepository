x = 0

lista_perguntas = ["Qual a fruta com mais acidez? " ,"Qual o melhor jogo de fps do mundo ?", "branco ou preto ?", "Roblox ou lol ?", "qual a cor do arco-iris? "]
lista_respostas = ["maça", "valorant", "branco", "lol", "branco"]

for i in range (5):
    pergunta = lista_perguntas[i]
    resposta_certa = lista_respostas[i]

    resposta = input(lista_perguntas[i])
    if resposta == resposta_certa:
        x = x + 1
        print("Nice.")

    else:
        print("Quase meu.")

print(f"sua nota final foi {x}")