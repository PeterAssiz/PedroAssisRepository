arquivo_alunos = open("Alunos.txt")

nomes_e_notas = arquivo_alunos.read()
nomes_e_notas = nomes_e_notas.split("\n")

arquivo_alunos.close()

arquivo_aprovados = open("Aprovados.txt",mode="w")
arquivo_reprovados = open("Reprovados.txt",mode="w")

for nome_e_nota in nomes_e_notas:
    # nome = nome_e_nota.split(":")[0]
    nota = 0
    if len(nome_e_nota.split(":")) >= 7:
        nota = int(nome_e_nota.split(":")[1])
    
    if nota >= 7:
        arquivo_aprovados.write(f"{nome_e_nota}\n")
    else:
        arquivo_reprovados.write(f"{nome_e_nota}\n")

arquivo_aprovados.close()
arquivo_reprovados.close()