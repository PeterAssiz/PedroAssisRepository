#Alunos: Pedro Gomes de Assis e Matheus Marques de Melo silva
#Série: 2º ano B

#Exercício 01 Contagem regressiva

import time

tempo = int(input("Coloque o valor da contagem regressiva: "))

def contagem(f:int):
    if(f <= 0):
        print(0)
    else:
        time.sleep(1)
        print(f)
        contagem(f-1)

print(contagem(tempo))

input("Pressione qualquer tecla para ir até o próximo Exercício")

#Exercício 02 Soma Recursiva

def somarecursiva(v:int):
    if (v <= 1): return 1
    else:
        return v + somarecursiva(v-1)
    
valor2 = int(input("Coloque aqui um valor: "))

print(somarecursiva(valor2))

input("Pressione qualquer tecla para ir até o próximo Exercício")

#Exercício 03 Potência

def potencia(base, expoente):
    if expoente == 0: return 1
    else: return base * potencia(base, expoente - 1) 

basev = int(input("Insira o valor da base: "))
expoentev = int(input("Insira o valor do expoente: "))

print(potencia(basev, expoentev))


input("Pressione qualquer tecla para ir até o próximo Exercício")

#Exercício 04 Reversão em String

def stringinv(s):
    if len(s) == 0: return " "
    else: 
        return s[-1] + stringinv(s[:-1])
    

name = input("Digite um nome para inverter: ")

print(stringinv(name))